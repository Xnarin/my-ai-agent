# financial_glossary_readable.pdf

- 쪽수: 25
- 거의 빈 쪽: 없음
- 표: 0개

## 1쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p001.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">금융용어 모음
휴면성 증권계좌
6개월 이상 매매, 입출금이 없는 계좌로서 예탁재산 평가액 10만원 이하인 계좌
후순위 보강
정책자금에서 우선손실충당 제공
후불교통카드 겸용 체크카드
체크카드에 교통카드 이용 편의를 제공할 목적으로 소액의 신용 이용한도(30만원)를 부여한 카드(여전법 令 제
6조의7)로 체크카드 발급시 후불교통카드 기능을 추가로 요청하면 사용할 수 있음
회수가능액
공정가치와 사용가치 중 더 큰 금액
확정기여형(DC) 퇴직연금
사용자(기업)가 매년 임금의 일정비율을 적립하고, 금융회사가 이를 근로자 지시에 따라 운용 후 퇴직 이후 운
용수익을 포함하여 적립된 연금을 지급
확정급여형(DB) 퇴직연금
사용자(기업)가 퇴직연금 재원을 금융회사에 적립하여 운용하고, 근로자 퇴직 이후 정해진 연금을 지급
합작특수목적회사(Joint Ventire Special Purpose Company)
매도자와 투자자가 공동출자하여 합작투자형식으로 부실자산을 매각하기 위해 설립한 유동화회사
프로젝트펀드
투자대상을 사전에 정해 놓고 자금을 모아 투자하는 방식의 펀드로, 기업구조혁신펀드의 신속한 투자집행 및
사례 축적 가능
표준감사시간심의위원회
표준감사시간을 정하기 위해 구성된 한국공인회계사회내 설치된 위원회- 총 15명으로 구성(회사측 5명, 금융감
독원장 추천 1명, 회계법인측 5명 및 회계정보이용자측 4명)
표준감사시간
감사업무의 품질을 제고하고 투자자 등 이해관계인의 보호를 위하여 감사인이 투입하여야 할 적정 감사시간
파생결합증권
주가지수, 개별주식, 금리, 원자재 등의 기초자산에 연동되어 투자수익이 결정되는 유가증권
투자일임업
투자자로부터 금융투자상품 등에 대한 투자판단의 전부 또는 일부를 일임받아 투자자별로 구분하여 그 투자자
의 재산상태나 투자목적 등을 고려하여 금융투자상품 등을 운용하는 업태
통일규격증권
원활한 주식거래를 위해 통일된 규격, 도안 등으로 발행한 주권 및 사채권, 신주인수권 증권
1</pre></td>
</tr></table>

## 2쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p002.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">크라우드펀딩(Crowdfunding)
온라인 상에서 다수의 투자자(crowd)로부터 자금을 조달(funding)하는 제도로 자금모집 및 보상방식에 따라 증
권형ㆍ대출형(P2P)ㆍ후원형(리워드형)ㆍ기부형으로 구분 가능
코스피200 및 코스닥150 지수
한국거래소 코스피·코스닥시장 상장종목 가운데 시장 대표성, 유동성, 업종 대표성을 기준으로, 시가총액이 상
위군에 속하고 거래량이 많은 종목을 선정해 지수화한 것(코스피 200종목, 코스닥 150종목)
코스닥 벤처펀드
조세특례제한법 상 요건*을 충족하는 경우 투자금액의 10%를 소득공제 받을 수 있고, 증권 인수업무 등에 관한
규정에 따라 코스닥 공모주 물량의 30%를 우선 배정받을 수 있는 펀드(투자한도는 제한이 없으나, 소득공제는
1인당 300만원까지 가능) * 펀드 조성 후 준수기간 이내로 펀드 자산의 15% 이상은 벤처기업 신주, 펀드 자산
의 35% 이상은 벤처기업·벤처기업 해제 후 7년 이내 코스닥 중소·중견기업 투자 필요 조세특례제한법 상 요건*
을 충족하는 경우 투자금액의 10%를 소득공제 받을 수 있고, 증권 인수업무 등에 관한 규정에 따라 코스닥 공모
주 물량의 30%를 우선 배정받을 수 있는 펀드(투자한도는 제한이 없으나, 소득공제는 1인당 300만원까지 가능)
* 펀드 조성 후 준수기간 이내로 펀드 자산의 15% 이상은 벤처기업 신주, 펀드 자산의 35% 이상은 벤처기업·벤
처기업 해제 후 7년 이내 코스닥 중소·중견기업 투자 필요
케이알앤씨(구 정리금융공사)
예금보험공사가 예금자보호법 제36조의3 규정에 의해 예금자 등의 보호 및 금융제도의 안정성 유지를 위해 금
융위원회의 승인을 얻어 부실금융회사의 영업 또는 계약을 양수하거나 정리업무를 수행하기 위하여 설립한 금
융회사
커버드본드
금융기관이 주택담보대출 등 우량자산을 담보로 발행하는 채권으로 투자자는 발행기관에 대한 상환청구권과
함께 발행기관이 담보로 제공하는 기초자산집합(Cover Pool)에 대하여 이중으로 제3자에 우선하여 변제받을
권리를 가짐
카히스토리
보험개발원이 중고차 소비자피해를 사전예방하고 중고차시장의 유통 투명성을 제고하기 위하여 운영 중인 서
비스로, PC 및 모바일( www-carhistory-or-kr)에서 차량번호를 입력하여 차량 일반사양 및 소유자·차량번호·용
도 변경이력, 보험사고이력 등에 대한 조회 서비스 제공
출자전환
채권자인 금융기관이 채무자인 기업에게 빌려준 대출금을 주식으로 전환해 기업의 부채를 조정하는 방식
총수익교환(TRS)
기초자산에서 발생하는 총수익과 일정한 현금흐름을 교환하는 장외파생상품
초과수익 이전
펀드운용 초과수익의 일정 부분을 투자자에게 이전
책임준비금
보험회사가 장래 보험금 지급 등에 충당하기 위하여 미리 적립하는 준비금
채무자대리인
대부업ㆍ미등록대부업자의 불법추심 차단을 위해 채무자 대신 변호사를 통해서만 추심하도록 하는 법률지원
제도(채권추심법 §8의2)
2</pre></td>
</tr></table>

## 3쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p003.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">채권소멸절차
전기통신금융사기 피해금 환급을 위해 사기이용계좌 명의인의 (예금)채권을 소멸시키는 절차
집합투자규약
펀드의 조직, 운영, 투자자의 권리‧의무를 정한 계약
지분매입옵션
투자기업 지분을 적정가격에 매입할 수 있는 옵션
지급정지
금융회사가 사기이용계좌의 입출금 및 이체를 금지시키는 행위
중소기업 특화 증권사
중소·벤처기업 기업금융에 특화된 증권사로서 2년마다 금융위원회에서 지정
주택연금
60세 이상 고령자 부부가 보유주택을 담보로 은행으로부터 매월 일정 금액을 대출 형태로 지급받는 상품(주택
금융공사 보증)
주식 대량보유공시제도 (소위 5% rule)
M&amp;A 시장의 공정성 제고 및 투자의사결정에 대한 유용한 정보 제공을 위해 주식 대량보유자(5% 이상)에 주식
보유-변동 상황 공시를 의무화
종합금융투자사업자
투자매매업자 또는 투자중개업자 중에서 자기자본 3조원 이상 등의 기준을 충족하고 금융위원회의 지정을 받
은 자
조건부자본증권
부실금융기관 지정 등 예정된 사유가 발생하면 자동으로 상각(상각형)되거나 보통주로 전환(전환형)되는 조건
이 붙은 사채
정책모기지
‘정책’+‘모기지’(Mortgage: 주택담보대출)의 합성어로, 정책목적(실수요자 지원, 시장구조 개선 등) 달성을 위해
공적재원 등을 기반으로 통상 시중보다 저금리로 제공하는 주택담보대출
정리제도
금융회사의 부실 발생 시 정리당국이 금융제도의 안정성 유지를 위해 자금지원, 계약이전 또는 청파산 등 정리
권한을 행사하여 해당 금융회사를 정상화 또는 퇴출시키는 제도
접근매체
전자식 카드, 공인인증서, 생체정보 등 전자금융거래에서 거래지시를 하거나 이용자 및 거래내용의 진실성과
정확성을 확보하기 위해 사용되는 수단
전환우선주
다른 종류의 주식으로 전환될 수 있는 권리가 부여된 우선주
전자적 장치
CD/ATM, 컴퓨터, 전화기 등 전자금융거래정보를 전자적 방법으로 전송하거나 처리하는데 이용하는 장치
3</pre></td>
</tr></table>

## 4쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p004.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">전자금융거래 제한
보이스피싱 피해 확산을 방지하기 위해 사기이용계좌 명의인의 타 계좌에 대해서도 전자금융거래(비대면거래)
를 제한시키는 조치
적격대출
주택금융공사와 은행간 업무협약에 의해 은행이 대출취급 후 주택금융공사로 양도가능한 유동화목적부 장기
고정금리·분할상환 대출
적격금융거래
사전에 마련된 기본계약을 근거로 개별거래를 체결하는 현물환거래, 파생금융거래 등을 의미하며 계약에 따라
기한 전 계약 종료권의 행사가 가능(채무자회생법 제120조제3항)
저축은행 특수관계인
본인과 배우자, 혈족 등의 관계에 있는 자로 저축은행의 대주주 여부 판단* 등에 활용되는 개념 * 예) 저축은행
의 최대주주는 본인과 특수관계인의 의결권 있는 저축은행 주식을 합산하였을 때 가장 많은 주식을 보유한 자
로 함 [저축은행법 제2조]
재보험 정산(Reconciliation and Settlement)
보험사와 재보험사 상호간에 지급해야 하는 보험료 및 보험금 금액을 계산하는 업무
자회사
50%를 초과하는 지분을 소유한 상법상 자회사(§342의2)
자산유동화증권(ABS, Asset-Backed Securities)
대출채권, 부동산, 외상매출금 등 보유하고 있는 자산을 담보로 증권을 발행하여 자산을 처분하기 전에 투자자
로부터 자금을 조달하는 금융기법
자산손상
자산을 매각하거나 사용하여 회수될 금액보다 자산의 장부금액이 크다면, 이 경우를 자산이 손상되었다고 함
자산건전성 분류
은행이 차주의 채무상환능력 등을 감안한 기대회수가치를 기준으로 보유자산의 건전성을 분류하는 기준으로, ‘
정상’, ‘요주의’, ‘고정’, ‘회수의문’, ‘추정손실’의 5단계로 분류 - 통상 ‘고정’ 이하 자산을 부실채권(NPL)이라 부르
며 자산건전성 등급이 떨어질수록 높은 비율의 대손충당금(예상손실금)을 적립하게 됨
자금세탁방지제도(AML: Anti-Money Laundering)
범죄수익을 추적하여 불법재산 등을 몰수,추징하는 것이 경제적 이익을 목적으로 하는 중대범죄 예방에 효과적
이라는 공감대 하에, ① 각 국은 “자금세탁”행위(가장,은닉)를 범죄화하고, 이를 몰수,추징하는 법적 장치를 구
축 * 우리나라도 ’01년「범죄수익은닉의 규제 및 처벌 등에 관한 법률」제정 ② 의심거래보고(STR), 고액현금
거래보고(CTR) 등을 통해 불법재산이 금융시스템을 이용하여 유통되는 것을 방지 * 우리나라는 ’01년「특정
금융거래정보의 보고 및 이용 등에 관한 법률」 제정
자금세탁방지의무
국제기준 및 특정금융거래보고법 상 명시된 의무로 고객에 대한 확인 의무, 자금세탁이 의심되는 거래 및 고액
현금거래를 FIU에 보고할 의무 등이 있음
자금세탁(ML: Money Laundering)
범죄행위로 얻은 불법재산을 적법하게 취득한 것으로 가장(假裝)하거나 은닉(隱匿)하는 행위
4</pre></td>
</tr></table>

## 5쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p005.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">일회성 금융거래
외환송금, 환전 등 금융회사에 계좌를 개설하지 않은 거래
인버스 ETF
추종지수(KOSPI200 등)와 반대방향으로 움직이는 ETF, 예컨대 추종하는 지수가 상승하면 해당 ETF는 하락
위험집중
금융그룹이 직면하는 위험이 해당 그룹의 지급여력, 재무상황을 위태롭게 할 만큼 특정 거래상대방 또는 산업
등에 편중되어 있는 경우
위탁증거금
증권사가 투자자로부터 증권의 매매거래를 수탁하는 경우 해당 투자자의 결제이행을 담보하기 위해 징수하는
현금 또는 증권
운영 리스크(Operational Risk)
부적절하거나 잘못된 내부의 절차, 인력, 시스템 및 외부사건으로 인해 발생하는 손실리스크(바젤委) ※ 예시 :
미흡한 내부통제 시스템 하에서의 과도한 위험상품 투자, 직원들의 주문 착오, 전산 시스템 장애로 인한 금융사
고, 대규모 법률소송 등
우선매수권
투자기업 지분을 타 출자자보다 우선 매수할 수 있는 옵션
오픈뱅킹
개별금융기관 및 핀테크업체가 오픈 API*를 통해 모든 금융기관 업무를 자체 제공할 수 있는 시스템으로, 현재
6개의 API** 제공 중 * 오픈 API(Application Programming Interface) : 데이터나 서비스를 외부에서 쉽게 접근해
활용할 수 있도록 제공하는 공개 응용 프로그램 기술 ** (조회) 잔액, 거래내역, 계좌실명, 송금인정보 (이체) 출
금, 입금
예금보험기금채권상환기금
공적자금으로 조성‧운용된 기존의 예금보험기금이 이전된 기금으로, 금융구조조정의 마무리와 공적자금의 회
수 및 상환업무를 수행하기 위해 설치된 기금을 의미
역외재간접펀드
하나의 외국 펀드의 집합투자증권에 투자하는 펀드
에스크로 방식
발주자가 대금을 은행 에스크로 계좌에 예치하고, 원사업자에게 예금인출권(민법상 지명채권)을 지급하면, 원
사업자는 수급사업자에게 자재구매‧외주용역 등에 대한 대금을 예금인출권 양도를 통해 결제하고, 원사업자‧수
급사업자는 예금인출권을 삼자간 동의후 에스크로 계좌의 현금으로 정산받는 서비스
업틱룰(uptick rule)
공매도에 따른 직접적인 가격하락 방지를 위하여 직전가격 이하로 공매도 호가제출을 금지하는 제도 * (예) A전
자 주식 직전가가 49,000원이라면, 공매도 호가는 49,050원, 49,100원 등 49,000원을 초과하는 금액으로만 제
출 가능 ㅇ 단, 시장조성자의 시장조성거래 목적의 공매도 호가에 대해서는 업틱룰 예외를 인정
액면병합
기 발행된 수 개의 증권의 액면을 합쳐 그보다 소수의 증권으로 전환하는 것- 액면분할과 반대
5</pre></td>
</tr></table>

## 6쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p006.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">실제소유자
고객을 최종적으로 지배하거나 통제하는 자연인으로서 해당 거래를 통하여 궁극적으로 혜택을 보는 개인(법인
등에 대해 최종적으로 효과적인 통제를 하는 자연인을 포함)
실기주 과실
투자자가 증권회사로부터 예탁원 명의로 된 주식을 실물출고한 후 권리(배당, 무상) 기준일 이전에 명의개서를
하지 않은 주식(실기주)에 대하여 발생한 배당금이나 주식(무상주, 주식배당주)
신협 공동유대
신용협동조합의 설립과 구성원의 자격을 결정하는 기본 영업범위 단위로 조합의 종류에 따라 지역조합은 시·군
또는 구의 읍·면·동, 직장조합은 같은 직장, 단체조합은 종교단체, 시장상인단체, 사단법인, 직종단체 등이 있음
신자산건전성분류기준(Forward Looking Criteria)
은행의 신용위험을 효율적으로 관리할 수 있도록 국제적 기준을 반영하여, 기업의 신용위험(Credit Risk)을 평
가할 때 &#x27;미래의 채무상환능력&#x27;을 주요 평가항목에 포함한 새로운 자산건전성 분류기준
신용평가
신평사가 기업 또는 기업이 발행하는 증권등의 신용상태를 평가하여 그 결과를 등급(예: AAA~D)으로 표기한
정보
신용거래
유가증권시장 또는 코스닥시장에서 매매거래를 함에 있어 투자자가 증권회사로부터 자금을 대여받아 하는 매
매거래
신복위 채무조정
신용회복위원회와 금융권 간 협약에 따라 연체채무자의 채무를 감면 후 분할상환토록 하여 경제적 재기를 지원
하는 채무조정 제도
시장조성자 제도
거래소가 증권회사와 시장조성계약을 체결하고 사전에 정한 종목(시장조성 대상 종목)에 대해 지속적으로 매도
ㆍ매수 양방향의 호가를 제시하도록 하여 유동성을 높이는 제도
스튜어드십 코드
“기관투자자의 수탁자 책임에 관한 원칙”을 지칭하며, 연기금 등 기관투자자가 고객 자산을 관리‧운용하는 수탁
자(스튜어드)로서 책임을 다하기 위해 이행해야 할 세부원칙과 기준을 담고 있음
손상차손
자산의 장부금액이 회수가능액을 초과하는 금액
소멸시효완성채권
금융채권의 소멸시효는 5년(상법 제64조)이나, 통상 법원의 지급명령 등을 통한 시효연장으로 연체 발생 후 약
15년 또는 25년 경과시 소멸시효 완성 - 소멸시효 완성시, 채무자는 더 이상 채무 변제의 의무가 없으나, (“시효
완성의 사실로서 채무는 당연히 소멸”, 대법원 1979-2-13- 선고 78다2157판결) - 채무자가 일부 변제하는 등의
경우, 시효의 이익 포기로 인정되어 채무 부활
선수금 환급보증(RG)
조선사의 선박건조 중 조선사 부도 등으로 선박인도가 불가능한 경우 금융회사가 선주에 선수금을 대신 지급하
기로 약정하는 보증
6</pre></td>
</tr></table>

## 7쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p007.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">상각채권
회수 가능성이 없는 부실채권을 재무상태표에서 제거하는 절차를 대손상각이라고 하며, 대손상각된 부실채권
을 상각채권으로 분류 (금융공공기관은 통상 ‘특수채권’으로 표현)
사잇돌 대출
중·저신용자에게 적정 금리의 자금 공급을 목적으로 서울보증보험과 연계하여 취급하는 중금리 보증대출상품
사용가치
자산에서 얻을 것으로 예상되는 미래현금흐름의 현재가치
사무관리회사
운용사의 펀드기준가격 산정업무 등을 위탁‧수행하는 회사
사기이용계좌
전기통신금융사기로 인해 피해자의 자금이 송금‧이체된 계좌 및 해당 계좌로부터 자금의 이전에 이용된 계좌
비청산장외파생상품
중앙청산소(CCP)에서 청산되지 않는 장외파생상품으로 거래상대방의 신용위험에 크게 노출
비조치의견서
금융회사등이 수행하려는 행위에 대해 금감원장이 향후 제재 등의 조치여부를 회신하는 문서
비소구 주택담보대출
채무자의 부도 발생시, 채무자의 상환 책임을 해당 담보물로 한정하는 대출제도
블라인드펀드
투자대상을 정하지 않은 상태에서 자금을 먼저 모으고 이후 투자처를 찾아 투자하는 방식의 펀드로, 미래에 나
타날 다수의 투자 건을 다룰 수 있어 기업구조혁신펀드에 참여하는 운용사의 구조조정 기업 투자역량 제고 가
능
부실채권
원금 또는 이자 상환이 연체된 채권으로 여신기관은 통상 3개월 이상 연체된 여신을 부실채권으로 분류하며, 보
증기관은 연체된 채권을 대위변제하고 보유한 구상채권을 부실채권으로 분류
부동산개발신탁
위탁자로부터 부동산을 수탁받고 이를 개발하여 발생하는 수익금(분양‧임대 등)을 수익자에 제공하는 구조의
신탁
복합금융그룹
여수신·보험·금투업 중 2개 이상 업종을 영위하는 금융그룹(단, 금융지주는 제외, 現 감독대상은 삼성, 한화, 미
래에셋, 교보, 현대차, DB 6개 금융그룹)
복층ㆍ순환 투자구조
하위 펀드부터 최상위 펀드까지 자사펀드에 3~4층 이상의 다층으로 투자(일명 ‘수직계열형’)하거나, 다층형으
로 자사펀드에 투자하면서 최상위펀드 또는 중위펀드가 다시 최하위 펀드 등에 순환하여 투자(일명 ‘순환투자
형’)하거나 또는 다층형으로 투자하면서 타사펀드를 통해 우회하여 자사펀드에 투자(일명 ‘순환투자우회형’)하
는 것
7</pre></td>
</tr></table>

## 8쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p008.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">보험다모아
생명·손해보험협회가 운영하는 보험상품 비교 플랫폼으로, PC 및 모바일(www-e-insmarket-or-kr)상에서 보험
상품을 쉽게 비교하고 가입할 수 있도록 보험료 비교정보 및 보험회사 홈페이지 바로가기 서비스를 제공
보험계리사
보험회사의 전반적인 위험을 분석·평가·진단하며 보험 상품 개발에 대한 인·허가, 보험료 및 책임준비금 산출 등
보험수리와 관련된 제반 업무를 담당하는 사람
법령해석 및 비조치의견서
금융회사 등이 수행하려는 행위 등에 대하여 금융당국이 관련 해석 및 제재조치 여부를 적극적으로 답변하여
법적 불확실성을 제거해 주는 제도
방카슈랑스
Bank+Insurance의 줄임말로, 은행 등 금융기관이 보험대리점으로서 보험상품을 판매하는 것을 말함
미수령주식ㆍ배당금
무상증자, 배당사실을 주주가 이사 등의 사유로 통지를 받지 못했거나 상속인이 상속사실을 인지하지 못하여
찾아가고 있지 않은 주식 또는 배당금
미수거래
전체 주식매입대금의 일부(통상적으로 40% 이상)에 해당하는 위탁증거금과 주식을 담보로 주식을 외상으로 매
입하는 제도- T+2 결제일까지 외상 금액을 갚지 않으면 증권사가 반대매매를 통해 계좌에 있는 주식을 처분
미니코스피200선물·옵션
코스피200선물과 동일하게 한국의 대표 주가지수인 코스피200지수를 기초자산으로 하는 선물ㆍ옵션 상품. ㅇ
다만, 계약금액을 1/5(거래승수 25만→5만)로 축소함으로써 소액투자가 가능한 등 투자자의 거래기회 제고 상
품
매입형 채무조정
공적기관 등이 금융회사로부터 연체된 채권을 매입하여 연체자에게 이자감면ㆍ상환기간 연장 등을 제공하는
채무조정의 한 방법
리파이낸싱
조달한 자금을 상환하기 위해 다시 자금을 조달하는 것
리츠(REITs)
부동산투자회사법에 따라 설립되어 투자자들로부터 자금을 모집, 부동산 개발·임대, 관련 채권 투자 등을 통해
발생한 수익을 배분하는 투자기구
로보어드바이저
자동화된 시스템을 활용하여 자산 배분·운용 등 자산관리와 관련된 금융서비스를 제공하는 도구(software)
레버리지 ETF
추종지수보다 가치가 더 변동하는 ETF, 예컨대 추종지수가 1% 상승하면 해당 ETF는 2% 상승
등급쇼핑(rating shopping)
회사채등 발행기업이 사전에 유리한 신용등급을 제시하는 신평사를 선택하여 신용평가를 받는 행태
8</pre></td>
</tr></table>

## 9쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p009.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">대환
새로운 대출을 일으켜 기존 대출을 갚는 것으로, 기존 대출보다 저렴한 금리로 빌릴 수 있을 때 이자부담을 줄이
는 방법으로 활용됨
대표회사
금융회사의 출자관계, 자산ㆍ자본총액 및 소유ㆍ지배구조 등을 고려하여 해당 금융그룹에 사실상 가장 큰 영향
력을 행사할 수 있는 금융회사
대체투자
기존의 전통적인 투자(주식, 채권 등) 이외의 새로운 투자를 통칭하는 용어로 파생결합상품, 부동산, SOC, 사모
펀드 등이 해당
단일가매매
일정시간 동안 접수한 호가를 하나의 가격으로 집중 체결하는 방식- 매매거래의 연속성이 단절된 경우 또는 주
가 급변 가능성이 높은 경우 등에 다수의 시장참가자 주문을 통해 새로운 균형 가격을 신속히 발견하는데 효율
적인 제도
내부회계관리제도 감사
주권상장법인의 내부회계관리제도가 효과적으로 설계 및 운영되는지 감사인이 직접 검증절차를 수행하여 합
리적 확신을 표명하는 절차
내부통제
조직 자체적으로 제정하여 이사회 및 임직원 등 모든 구성원들이 이행하여야 하는 절차로 내부감사, 위험평가
체계 등 조직 전반에 대한 통제를 포괄하는 개념
기업재무안정 PEF
재무구조개선기업(부실징후기업, 재무구조개선약정 체결기업 등)에 투자·운용하는 사모펀드
기업구조조정투자회사(CRV, Corporate Restructuring Vehicle)
금융회사가 대출금 출자전환에 따라 보유하게 된 주식을 전문적으로 관리하거나 매입해 주는 기관
기본예탁금
증권사가 개인 위탁자로부터 금융투자상품의 매매거래를 수탁하는 경우 예탁 받아야 하는 일정금액 이상의 현
금 또는 대용증권
금융그룹 통합감독에 관한 원칙(Principles for the Supervision of Financial Conglomerates)
국제금융감독기구 협의회[업권별 감독기구(BCBS·IOSCO·IAIS)와 각국 금융감독기구로 구성된 Joint Forum]가
’99년 공개(’12년 수정)한 금융그룹 감독에 관한 기본원칙
금융그룹 통합감독
｢금융지주회사법｣을 적용받는 금융지주그룹 이외의 금융그룹(예: 금융모회사 그룹, 금산결합 금융그룹)에 대한
통합 재무건전성 및 위험관리 등에 대한 감독
금융그룹 감독원칙
Joint Forum에서 제시한 ①지배구조, ②자본적정성ㆍ유동성, ③리스크관리, ④감독자 권한, ⑤감독자 책임 등 5
개 부문에 관한 감독원칙
9</pre></td>
</tr></table>

## 10쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p010.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">금융그룹 감독대상
여수신·보험·금투업 중 2개 이상 업종을 영위하는 금융그룹으로서 감독 실익이 있는 경우(단, 금융지주회사 등
은 제외, 現 감독대상은 교보, 미래에셋, 삼성, 한화, 현대차, DB 6개 금융그룹)
금융규제 테스트베드(Regulatory sandbox)
혁신적 금융서비스를 완화된 규제환경(Sandbox) 하에서 일정기간 시범운영하도록 허용하는 것
금융규제 샌드박스
새롭고 혁신적인 혁신금융서비스에 대해서는 금융법상 인허가 및 영업행위 등 규제를 최대 4년간(2+2년) 적용
유예·면제해주는 제도
금리인하요구권
은행 및 보험회사와 신용공여 계약을 체결한 자가 신용상태가 개선된 경우 은행 등에 금리인하를 요구할 수 있
는 권리
그룹위험
동일그룹內 특정 계열사의 부실이 금융부문 전체로 전이되는 위험(전이위험), 금융그룹의 위험노출액이 특정분
야에 편중되어 금융그룹의 지급여력이나 재무상태를 위태롭게 할 만큼의 충분한 위험(집중위험) 등을 모두 고
려한 그룹 차원의 고유한 위험
국제기준
효과적인 자금세탁방지 및 테러자금조달 금지를 위해서 각 국이 이행해야 할 40가지 항목의 권고기준 * 자금세
탁방지기구(FATF)는 AML(자금세탁방지)·CFT(테러자금조달금지)을 효과적으로 이행하기 위해서 각 국이 이행
해야 할 40가지 항목의 기준(금융회사의 의무, 수사·몰수, 국제협력 등)을 발표
괴리율
[(시장가격-지표가치)/지표가치]×100- 시장가격과 지표가치의 차이를 나타내는 지표
공제
가입자간 상호부조를 목적으로 공제료를 갹출·적립하고 사고발생시 공제금을 지급하는 사업으로, 보험업법상 &#x27;
보험&#x27;으로 허가를 받지 않음(각각의 설립근거법에 따라 운영되며, 개별부처에서 관리·감독)
공적자금
1997년 말 외환위기 이후 금융부실이 누적되면서 경색된 금융시장을 조속히 정상화시키고 이를 통해 급속하게
위축되던 실물경제를 회복시키고자 금융구조조정 등에 사용된 자금을 말하며, 예금보험기금채권상환기금, 부
실채권정리기금, 구조조정기금, 공공자금관리기금 등의 기금 또는 재산 등에서 금융회사 또는 기업의 구조조정
에 지원되는 자금을 의미(공적자금관리특별법 제2조제1호)
공모추가형 펀드
설정ㆍ설립일 이후에도 집합투자증권을 추가로 발행할 수 있는 펀드
공동재보험
원보험사가 위험보험료 외에 저축보험료 등의 일부도 재보험사에 출재하고 보험위험 이외 금리위험 등 다른 위
험도 재보험사에 이전하는 재보험(유럽 등 해외에서는 Co-Insrance(공동보험)란 용어를 사용)
공동대출
2개 이상의 조합이 동일 채무자를 대상으로 동일한 물건에 동일 순위로 근저당권(신탁수익권 포함)을 설정하여
취급하는 담보대출(일종의 신디케이트론)
10</pre></td>
</tr></table>

## 11쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p011.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">고액현금거래보고
금융회사가 2,000만원 이상의 현금거래에 대해서 FIU에 보고하는 제도(Currency Transaction Repot)
고객확인제도
금융회사가 거래상대방에 대하여 신원, 실제소유자 등을 확인하고, 자금세탁 등의 위험이 높을 경우 자금원천
등을 추가로 확인·모니터링하는 제도
경영참여형 사모펀드(PEF, Private Equity Fund)
경영권 참여, 사업구조ㆍ지배구조 개선 등을 위해 지분증권 등에 투자ㆍ운용하는 사모펀드
거래정보저장소
장외파생상품의 거래정보를 수집·관리하고 금융당국에 보고하는 역할을 수행하는 거래정보 등록기관
감사인선임위원회
감사위원회가 없는 주권상장법인·대형비상장주식회사·금융회사가 감사인 선임과 관련한 업무를 승인받기 위
하여 외부감사법에 따라 구성하는 조직
감사인 지정
지정사유가 발생한 회사에 대하여 증권선물위원회가 지정한 회계법인을 감사인으로 선임·변경하도록 요구하
는 제도
TRS(Total Return Swap)
증권사가 일정 증거금을 담보로 주식ㆍ채권ㆍ메자닌 등 자산을 운용사 대신 매입해주는 스왑 계약 → 증거금(담
보)을 초과한 자산 매입분은 펀드가 증권사로부터 일종의 ‘대출’을 받는 효과
TDF(Target Date Fund)
은퇴예상시점까지 남은 기간 등에 따라 자산구성을 지속 변동(예- 주식/채권 비율 80:20 → 50:50 → 20:80)시키
는 방식으로 수익성과 안정성을 동시에 추구하는 펀드
TDB(Tech DataBase)
기술신용평가에 필요한 기술･시장･기업 정보를 제공하는 데이터베이스
TCB(Tech Credit Bureau)
&quot;기업이 보유한 기술정보와 신용정보를 결합･평가하여 기술신용등급을 산출･조회･제공 * 현재 기술보증기금,
나이스평가정보, KED, 이크레더블, 나이스디앤비가 TCB 수행중(2017년 기준)&quot;
T+2일 결제제도
장내주식의 거래 이후에는 청산* 및 결제* 처리절차가 필요하며, 국내 주식시장은 매매거래일(T)로부터 2거래
일(T+2)에 증권ㆍ대금이 결제 * (청산) 모든 매도·매수자의 채권·채무가 거래소를 통해 확정되는 절차(결제) 거
래에 따라 주식 매도자는 매수자에게 주식을, 매수자는 매도자에게 현금을 지급하여 법적인 의무가 완료되는
절차 ※ (T+2일 결제국) 미국, 일본, 홍콩, 독일, 영국, 프랑스, 이탈리아 등(T+3일 결제국) 싱가포르, 인도네시아,
멕시코, 캐나다 등
SIFI(Systemically Important Financial Institution)
시스템적 중요 금융회사(SIFI)란 부실 발생시 금융시스템에 중대한 영향을 미치는 금융회사를 의미하며, 규모,
상호연계성, 대체가능성, 복잡성 등을 고려하여 FSB가 Global SIFI를 매년 선정(‘19년 30개)하고, 각국 금융당
국이 Domestic SIFI를 매년 선정
11</pre></td>
</tr></table>

## 12쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p012.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">Self-Indexing
증권회사 또는 자산운용사 등 발행사가 직접 기초지수를 개발·산출하고 이를 상품화하는 것
Sale &amp; Leaseback
① 채무조정의 한 형태로, 연체자가 공적기관에 주택을 매각해 대출을 갚고 해당주택에 장기 임차거주하는 프
로그램 ② 공장 등 기업자산을 캠코가 매입한 후 해당 기업에게 임대료를 받고 재임대하여 기업의 영업 기반을
유지하는 프로그램
PEF 업무집행사원
PEF의 재산운용 등을 담당하는 사원
PBS(Prime Brokerage Service)
증권사가 사모펀드 운용에 필요한 증권대차, 신용공여, 펀드재산의 보관·관리 등 일련의 서비스를 연계하여 종
합적으로 제공하는 업무
MMF(Money Market Fund, 단기금융집합투자기구)
펀드 재산을 단기금융상품에 주로 투자하고, 수시입출금이 가능한 펀드
M&amp;A
기업의 인수·합병(Merger &amp; Acquisitions)
K-OTC
금융투자협회가 운영하는 거래체결기능을 보유한 제도권 내 비상장주식 거래시장
IPO(기업공개, Initial Public Offering)
기업의 증권시장 상장 등을 위하여 해당 기업의 주식을 불특정 다수의 투자자들에게 공개 매도하는 절차
IMF FSAP(Financial Sector Assessment Program)
글로벌 금융시스템의 상호연계성이 높아짐에 따라, IMF는 주요국* 금융부문의 안정성에 대한 주기적 평가 실시
* 시스템적으로 중요한 29개 국가(systemically important jurisdictions) 및 자율적으로 FSAP을 신청한 국가를
대상으로 약 5년마다 실시/ 한국: 1차(’03년), 2차(’14년) 3차(’20년)
FSB(Financial Stability Board)
09-4월 설립된 글로벌 금융규제 협의체로, G20의 요청에 따라 글로벌 금융시스템의 안정성을 제고하기 위한
금융규제 국제기준 및 권고안을 개발- 24개 회원국 및 EU 중앙은행, 국제기구(BCBS, IOSCO, IAIS, IMF, WB
등)가 회원기관으로 참여 (한국의 경우 금융위원회와 한국은행이 참여)
FATF 상호평가
국제자금세탁방지기구(FATF)는 AML(자금세탁방지)·CFT(테러자금조달금지)을 효과적으로 이행하기 위한 체
제 구축 여부와 그간의 성과 등을 평가
FATF
Financial Action Task Force on Money Laundering&#x27;의 약자. UN 협약 및 UN 안보리결의(UNSCR) 관련 금융조
치 (Financial Action)의 이행을 위한 행동기구 (Task Force)로 1989년 G7 합의로 설립
ETN
상장지수증권(Exchange Traded Note)의 줄임말- 증권사가 만기에 기초지수의 수익률에 연동하는 수익의 지급
을 약속하는 파생결합증권
12</pre></td>
</tr></table>

## 13쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p013.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">ETF(Exchange Traded Fund, 상장지수집합투자기구)
특정자산의 가격 또는 특정지수의 변화에 연동하여 운용하는 것을 목표로 하여 거래소에 상장되어 주식처럼 거
래되는 펀드
ELW
주식워런트증권(Equity Linked Warrant)의 줄임말- 주식 및 주가지수 등의 기초자산을 사전에 정한 미래의 시점
에 미리 정해진 가격에 사거나 팔 수 있는 권리를 나타내는 파생결합증권
DIP금융
DIP(Debtor In Possession)는 회생절차기업의 기존경영인을 유지하는 제도로, 통상 회생절차 기업에 대해 운전
자금 등 신규자금을 지원하는 것
CB사(Credit Bureau, 개인신용조회회사)
금융기관, 기업 등으로부터 신용정보를 수집하여 이를 평가하고 개인의 신용상황을 판단할 수 있는 정보를 금
융회사 등에게 제공·판매하는 회사
Capital Call
출자금을 일시에 납입하지 않고, 약정한도내에서 출자 이행의 요구가 있는 때에 출자하는 방식
BIS 자기자본비율(BIS 비율)
BIS(Bank for International Settlement ; 국제결제은행)가 정한 은행의 위험자산(부실채권) 대비 자기자본비율
ARS(Autonomous Restructuring Support)
회생절차 신청 후 개시 결정 사이에서 기업·채권자의 자율적 구조조정 절차를 진행하는 제도로, 자율구조조정
이 성사되면 회생절차 진행하지 않음
금융체계상 중요한 금융기관(SIFI, Systemically Important Financial Institution)
금융위는 금융기관의 기능과 규모, 다른 금융기관의 연계성 및 금융시장에 미치는 영향력 등을 고려하여 매년
국내 금융시스템 측면에서 중요한 금융기관을 선정
정리제도
금융회사의 부실 발생 시 정리당국이 금융제도의 안정성 유지를 위해 자금지원, 계약이전 또는 청파산 등 정리
권한을 행사하여 해당 금융회사를 정상화 또는 퇴출시키는 제도
FSB(Financial Stability Board)
&#x27;09.4월 설립된 글로벌 금융규제 협의체. G20의 요청에 따라 글로벌 금융시스템의 안정성을 제고하기 위한 금
융규제 국제기준 및 권고안을 개발. 24개 회원국 및 EU 중앙은행, 국제기구(BCBS, IOSCO, IAIS, IMF, WB 등)
가 회원기관으로 참여
채권자 손실분담제도(Bail-in)
부실금융회사의 손실흡수 및 자본확충을 위하여 부실금융회사에 대한 채권을 출자전환 및 상각하는 제도. 금융
회사 정리에 따른 손실을 주주뿐만 아니라 채권자도 분담하도록 하는 제도
적격금융거래(「채무자 회생 및 파산에 관한 법률」상 적격금융거래)
국제 파생상품 기본계약서(ISDA, International Swaps and Derivatives Association) 등에 근거하여 체결한 통화,
유가증권, 이자율 등을 기초로 하는 파생금융거래 등 * 「채무자 회생 및 파산에 관한 법률」 제120조 ③ ... &quot;기
본계약&quot;...에 근거하여 다음 .. 거래(이 항에서 &quot;적격금융거래&quot;라고 한다) ... (생략) - 통화, 유가증권 또는 이자율
등을 대상으로 하는 선도, 옵션, 스왑 등 파생금융거래 - 현물환거래, 유가증권의 환매거래, 유가증권의 대차거
래 및 담보콜거래
13</pre></td>
</tr></table>

## 14쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p014.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">개인대주제도
증권시장에서의 매매거래를 위하여 개인투자자에게 매도증권을 대여해 주는 제도로 , 개인투자자의 공매도 창
구로 활용
공매도
향후 주가가 하락할 것으로 예상되는 종목의 주식을 빌려서 매도한 뒤 실제로 주가가 하락하면 주식을 되사들
여 빌린 주식을 갚음으로써 차익을 얻는 매매기법
신용공여
투자매매업자 또는 투자중개업자가 투자자에게 금전을 대출하거나 ( 신용거래융자 ) 증권을 대여하는 것 ( 신용
거래대주 )
전문투자자
금융투자상품에 관한 전문성 구비 여부 · 소유자산규모 등에 비추어 투자에 따른 위험감수능력이 있는 투자자
유상증자
상법상 주식회사가 주식을 추가 발행해서 돈을 받고 주식을 팔아 자금을 조달하는 수단으로 , 회사가 돈을 받지
않고 주식을 추가로 발행하는 무상증자와 구분되는 개념
감독분담금
금감원이 제공하는 감독ㆍ검사서비스에 대한 대가로 검사대상 금융회사가 금감원에 납부하는 수수료(금융위
설치법 §47①)
발행분담금
금감원이 제공하는 공모발행증권 심사서비스에 대한 대가로 증권발행인이 금감원에 납부하는 수수료(자본시
장법 §442)
공매도
향후 주가가 하락할 것으로 예상되는 종목의 주식을 빌려서 매도한 뒤 실제로 주가가 하락하면 주식을 되사들
여 빌린 주식을 갚음으로써 차익을 얻는 매매기법
백워데이션(back-wardation)
선물가격이 현물가격보다 낮게 형성된 시장 또는 선물과 현물 간의 가격 역전현상을 의미하며, 백워데이션 하
에서는 저평가된 선물을 매수하고 고평가된 현물을 매도하는 차익거래 수요가 발생
시장조성자(market maker)
매수·매도 양방향에 호가를 제시하여 투자자의 거래상대방이 되어주는 자기매매업자(통상 증권사)로, 원활한
거래를 뒷받침하여 투자자 거래비용을 절감하고, 가격연속성을 제고하는 기능을 수행
업틱룰(up-tick rule)
공매도 시 매도호가를 직전 체결가 초과로 제시하도록 제한한 규정
금융체계상 중요한 금융기관(SIFI, Systemically Important Financial Institution)
금융위는 금융기관의 기능과 규모, 다른 금융기관의 연계성 및 금융시장에 미치는 영향력 등을 고려하여 매년
국내 금융시스템 측면에서 중요한 금융기관을 선정
정리제도
금융회사의 부실 발생 시 정리당국이 금융제도의 안정성 유지를 위해 자금지원, 계약이전 또는 청파산 등 정리
권한을 행사하여 해당 금융회사를 정상화 또는 퇴출시키는 제도
14</pre></td>
</tr></table>

## 15쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p015.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">적격금융거래(「채무자 회생 및 파산에 관한 법률」상 적격금융거래)
국제 파생상품 기본계약서(ISDA, International Swaps and Derivatives Association) 등에 근거하여 체결한 통화,
유가증권, 이자율 등을 기초로 하는 파생금융거래 등 * 「채무자 회생 및 파산에 관한 법률」 제120조 ③ ... &quot;기
본계약&quot;...에 근거하여 다음 .. 거래(이 항에서 &quot;적격금융거래&quot;라고 한다) ... (생략) - 통화, 유가증권 또는 이자율
등을 대상으로 하는 선도, 옵션, 스왑 등 파생금융거래 - 현물환거래, 유가증권의 환매거래, 유가증권의 대차거
래 및 담보콜거래
기관전용 사모펀드
전문성‧위험관리능력을 고려하여 자본시장법령에서 정한 투자자만 투자할 수 있도록 투자자가 제한된 사모펀
드(법 §9⑲1.) * 기관전용 사모펀드는 업무집행사원(GP, 非금융투자업자)이 설립‧운용
일반 사모펀드
자본시장법령에서 정한 적격투자자(전문투자자+최소투자금액(3억원) 이상 투자하는 일반투자자)가 투자할 수
있는 사모펀드(법 §9⑲2.) * 일반 사모펀드는 사모운용사(금융투자업자)가 설정‧운용
일반투자자 대상 일반 사모펀드
일반투자자(전문투자자가 아닌 자)가 투자할 수 있는 일반 사모펀드. 개정법령은 일반투자자 대상 일반 사모펀
드에 강화된 투자자 보호장치를 도입 * 핵심상품설명서 교부, 자산운용보고서 교부, 외부감사, 판매사‧수탁사의
운용감시 등
ROA(Return To Asset)
부채를 포함한 총 자산 대비 순수익
ROE(Return To Equity)
자기자본 대비 순수익
ABCP(AB전단채)
유동화전문회사가 자산을 양도받아 이를 기초로(Asset-Backed) 기업어음(CP), 전자단기사채(만기 1년 미만)를
발행하고, 기초자산 운용 수익금 등으로 CP, 사채의 원리금 등을 지급
감사인
공인회계사가 설립하고 금융위원회에 등록한 회계법인 또는 한국공인회계사회에 등록한 감사반으로서 회사의
재무제표에 대한 외부감사를 수행하는 자
지정감사
감사인의 독립성 확보와 외부감사의 공신력을 제고할 목적으로 증권선물위원회가 감사인을 지정하는 제도(외
감법 §11)
주기적 지정제
연속하는 6개 사업연도의 감사인을 자유선임한 주권상장법인(코넥스 제외) 및 소유ㆍ경영미분리 대형비상장주
식회사*의 다음 3개 사업연도 감사인을 증권선물위원회가 지정하는 제도(외감법 §11②) * ①직전 사업연도말
자산규모가 1천억원 이상인 비상장회사로서 ②지배주주 및 특수관계자의 지분율이 50%이상이고, ③지배주주
및 특수관계자인 주주가 대표이사인 회사
표준감사시간
감사업무의 품질제고 및 이해관계인의 보호를 위하여 한국공인회계사회(표준감사시간심의위위원회)가 이해관
계자의 의견수렴 * 을 거쳐 정한 감사인이 투입하여야 할 표준시간(외감법 §16의2) * 회사 및 회계법인을 대표
하는 위원 각 5명, 회계정보이용자를 대표하는 위원 4명, 금융감독원장이 추천하는 위원 1명이 표준감사심의위
원회를 구성하여 심의
15</pre></td>
</tr></table>

## 16쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p016.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">전기ㆍ당기
회사의 직전 사업연도 및 당해 사업연도를 말함
기관전용 사모펀드
전문성‧위험관리능력을 고려하여 자본시장법령에서 정한 투자자만 투자할 수 있도록 투자자가 제한된 사모펀
드(법 §9⑲1.) * 기관전용 사모펀드는 업무집행사원(GP, 非금융투자업자)이 설립‧운용
일반 사모펀드
자본시장법령에서 정한 적격투자자(전문투자자+최소투자금액(3억원) 이상 투자하는 일반투자자)가 투자할 수
있는 사모펀드(법 §9⑲2.) * 일반 사모펀드는 사모운용사(금융투자업자)가 설정‧운용
일반투자자 대상 일반 사모펀드
일반투자자(전문투자자가 아닌 자)가 투자할 수 있는 일반 사모펀드. 개정법령은 일반투자자 대상 일반 사모펀
드에 강화된 투자자 보호장치를 도입 * 핵심상품설명서 교부, 자산운용보고서 교부, 외부감사, 판매사‧수탁사의
운용감시 등
전환사채(Convertible Bonds)
회사가 발행하는 사채(社債)로서 사채 보유자의 의사에 따라 사채를 발행하는 회사의 주식으로 전환할 수 있는
전환권이 부착된 사채
국제회계기준(IFRS)재단
국제재무보고기준을 제정하는 비영리조직으로 회계기준을 제정하는 국제회계기준위원회(IASB), 지속가능성
공시기준을 제정하는 국제지속가능성기준위원회(ISSB) 등으로 구성
IFRS 지속가능성 공시
기업가치에 단기, 중기, 장기적인 영향을 미치는 기후, 환경 등 지속가능성 관련 사안들에 대한 정보 공시
신속 이전상장제도
코넥스에서 뛰어난 경영성과를 보이는 등 일정 요건을 충족하는 법인에 대해 코스닥 상장요건을 일부 완화하여
코스닥으로 신속히 이전상장 할 수 있도록 하는 특례 제도
지정자문인
코넥스 상장 추진 법인에 대한 상장적격성을 심사하고, 상장 이후에는 해당 법인에 유동성 공급, 법률자문, 공시
ㆍ신고업무 대리, 각종 자문 지원 등을 수행하는 금융투자업자
기본예탁금
위험 감수능력 등을 갖춘 투자자에 한해 시장참여가 가능하도록, 코넥스 시장에서 주식을 매수하려는 투자자에
대해 일정 금액(현행 3천만원) 이상을 예탁하도록 하는 제도
소액투자 전용계좌
납입한도(年 3천만원) 내에서 코넥스 주식을 매수할 수 있도록 하는 계좌(모든 증권사 포함 1인 1계좌만 개설
가능)
기본예탁금
코넥스 시장에서 주식을 매수하려는 개인투자자는 일정 금액(현행 3천만원) 이상을 예탁
소액투자 전용계좌
납입한도(年 3천만원) 내에서 코넥스 주식을 매수할 수 있는 계좌(현재 모든 증권사 포함 1인 1계좌만 개설 가
능)
16</pre></td>
</tr></table>

## 17쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p017.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">신속 이전상장제도
코넥스에서 뛰어난 경영성과를 보이는 등 일정 요건을 충족하는 법인에 대해 코스닥 상장요건을 일부 완화하여
코스닥으로 이전상장을 쉽게 할 수 있도록 특례 부여
지정자문인
코넥스 상장 추진 법인에 대한 상장적격성을 심사하고, 상장 이후에는 해당 법인에 유동성 공급, 법률자문, 공시
ㆍ신고업무 대리, 각종 자문 지원 등을 수행하는 금융투자업자
상장사 감사인 등록제도
상장회사를 감사하기 위해서는 통합 품질관리체계 등 등록요건을 충족하고 금융위원회에 등록해야 함
감사인 지정제도
독립적인 외부감사가 필요한 기업에 대해 증권선물위원회가 해당 기업의 외부감사인을 지정하는 제도
감사인 지정점수
지정감사인을 정하기 위해 산정하는 회계법인의 점수로 회계사 수 및 경력기간, 회계감사 매출액 비중 등을 기
반으로 산정
감사인 지정제외점수
외부감사법 등을 위반한 회계법인에게 증선위가 부과하는 조치로 누적 점수 90점은 자산 5조원이상, 60점은 자
산 4천억원이상, 30점은 자산 4천억원 미만 1개 회사를 지정 회사에서 차감
SPAC(기업인수목적회사)
비상장기업 인수합병을 목적으로 하는 서류상 회사로 「자본시장법 시행령」제6조제4항제14호에 따라 설립된
법인
상향·하향 재지정
기업이 속한 군보다 하위군의 감사인을 지정받은 경우 상위군 감사인으로 재지정을 요청(상향) / 기업이 속한
군보다 상위군의 감사인을 지정받은 경우 하위군 감사인으로 재지정을 요청(하향) 할 수 있는 제도
동일군 재지정
기업에 지정된 감사인이 속한 군 내에서 다른 감사인으로 재지정을 요청할 수 있는 제도
품질관리감리
증선위는 회계법인의 품질관리기준 준수 여부에 대한 감리 결과 필요한 경우 개선권고 및 개선권고사항 외부
공개를 할 수 있음
내부회계관리제도
신뢰성 있는 회계정보의 작성·공시를 위해 회사가 설계·운영하는 내부회계관리규정과 이를 관리하는 조직
국제회계기준(IFRS)
국제회계기준위원회(IASB, International Accounting Standards Board)가 공표한 회계기준으로 한국을 포함한
140여개 국가가 도입 및 적용하고 있는 회계기준
국제감사기준(ISA)
국제감사인증기준위원회(IAASB, International Auditing and Assurance Standards Board)가 제정하는 감사기
준으로 한국을 포함한 130여개 국가가 도입 및 채택하고 있는 감사기준
17</pre></td>
</tr></table>

## 18쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p018.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">P-CBO(Primary – Collateralized Bond Obligations, 신규발행채권담보부 증권)
신용도가 낮은 중소기업들의 회사채 등을 모아 신용보증기금의 보증 하에 발행되는 증권으로, 회사채 직접 발
행이 곤란한 기업의 자금조달을 지원하는 제도
PF(Project Financing)
사회기반시설 건설이나 택지개발과 같은 대규모 사업에 필요한 자금을 조달하기 위해 동원되는 대출 등 금융수
단이나 투자기법
Sales &amp; Lease Back(매각 후 재임대)
기업이 보유자산(부동산, 생산설비 등)을 금융회사에 매각하여 받은 대금을 운영자금 등으로 활용하고, 매각된
자산은 금융회사로부터 재임차하여 사용함으로써 기업이 유동자금을 확보할 수 있도록 하는 금융기법
BDC(Business Development Company, 기업성장집합투자기구)
벤처·혁신기업 등에 집중 투자하고 상장을 통해 환금성을 높인 공모형 펀드
D-테스트베드(D-Testbed)
핀테크 스타트업이 사업아이디어 등을 검증할 수 있도록 금융권 데이터 및 테스트 환경을 제공하는 사업
ESG
환경·사회·지배구조(Environment, Social, Governance)
ISSB
국제지속가능성기준위원회(International Sustainability Standards Board), ’21.11월 IFRS재단 산하에 설립된
위원회로, 글로벌 지속가능성 공시기준을 제정 중
IFRS S1,S2
IFRS의 지속가능성 공시기준, S1(일반 요구사항), S2(기후 관련 공시)
IOSCO
국제증권감독기구(International Organization of Securities Commissions)
ESRS
유럽 지속가능성보고기준(European Sustainability Reporting Standards)
SEC
미국 증권거래위원회(Securities and Exchange Commission)
부수·겸영업무
은행업무는 고유업무 ( 은행법 §27), 부수업무 ( 은행법 §27 의 2), 겸영업무 ( 은행법 §28) 로 구분되며 , 부수업
무 중 일부 ( 은행법규에 규정되지 않은 부수업무 ) 와 겸영업무 는 해당 은행이 금융위원회에 사전 신고를 해야
영위 가능
책무구조도
금융회사 임원 개개인이 책임져야 하는 내부통제 대상 업무의 범위와 내용을 금융회사가 스스로 각자의 특성을
고려하여 사전에 정하도록 하는 제도 (’24.7.3 일 , 개정 「 금융사지배구조법 」 시행 예정 )
IFRS재단
국제재무보고기준 (International Financial Reporting Standards) 재단 , 전세계 약 146 개국이 도입하고 있는 국
제회계기준 (IFRS 회계기준 ) 등을 제정하는 국제기구
18</pre></td>
</tr></table>

## 19쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p019.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">IFRS 자문평의회
투자자 , 재무분석가 , 재무제표 및 지속가능성 공시 담당자 , 이용자 , 기준 제정기구 , 교수 , 회계법인 및 감독
기구를 대표하는 인원으로 구성 ( 현재 57 명 )
IASB
국제회계기준위원회 (International Accounting Standards Board)
IFRS 해석위원회
IASB 위원인 위원장 (Bruce Mackenzie, 남아공 ) 과 회계법인 , 기업 및 재무제표 이용자 출신의 14 명의 위원
으로 구성
19</pre></td>
</tr></table>

## 20쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p020.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">출처 목록
휴면성 증권계좌 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1697&amp;curPage=23
후순위 보강 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1698&amp;curPage=23
후불교통카드 겸용 체크카드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1699&amp;curPage=23
회수가능액 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1700&amp;curPage=23
확정기여형(DC) 퇴직연금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1701&amp;curPage=23
확정급여형(DB) 퇴직연금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1702&amp;curPage=23
합작특수목적회사(Joint Ventire Special Purpose Company) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1703&amp;curPage=23
프로젝트펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1704&amp;curPage=23
표준감사시간심의위원회 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1705&amp;curPage=23
표준감사시간 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1706&amp;curPage=22
파생결합증권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1707&amp;curPage=22
투자일임업 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1708&amp;curPage=22
통일규격증권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1709&amp;curPage=22
크라우드펀딩(Crowdfunding) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1710&amp;curPage=22
코스피200 및 코스닥150 지수 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1711&amp;curPage=22
코스닥 벤처펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1712&amp;curPage=22
케이알앤씨(구 정리금융공사) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1713&amp;curPage=22
커버드본드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1714&amp;curPage=22
카히스토리 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1715&amp;curPage=22
출자전환 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1716&amp;curPage=21
총수익교환(TRS) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1717&amp;curPage=21
초과수익 이전 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1718&amp;curPage=21
책임준비금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1719&amp;curPage=21
채무자대리인 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1720&amp;curPage=21
채권소멸절차 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1721&amp;curPage=21
집합투자규약 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1722&amp;curPage=21
지분매입옵션 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1723&amp;curPage=21
지급정지 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1724&amp;curPage=21
중소기업 특화 증권사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1725&amp;curPage=21
주택연금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1726&amp;curPage=20
주식 대량보유공시제도 (소위 5% rule) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1727&amp;curPage=20
종합금융투자사업자 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1728&amp;curPage=20
조건부자본증권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1729&amp;curPage=20
정책모기지 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1730&amp;curPage=20
정리제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1731&amp;curPage=20
접근매체 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1732&amp;curPage=20
전환우선주 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1733&amp;curPage=20
전자적 장치 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1734&amp;curPage=20
전자금융거래 제한 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1735&amp;curPage=20
적격대출 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1736&amp;curPage=19
적격금융거래 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1737&amp;curPage=19
20</pre></td>
</tr></table>

## 21쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p021.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">저축은행 특수관계인 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1738&amp;curPage=19
재보험 정산(Reconciliation and Settlement) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1739&amp;curPage=19
자회사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1740&amp;curPage=19
자산유동화증권(ABS, Asset-Backed Securities) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1741&amp;curPage=19
자산손상 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1742&amp;curPage=19
자산건전성 분류 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1743&amp;curPage=19
자금세탁방지제도(AML: Anti-Money Laundering) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1744&amp;curPage=19
자금세탁방지의무 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1745&amp;curPage=19
자금세탁(ML: Money Laundering) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1746&amp;curPage=18
일회성 금융거래 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1747&amp;curPage=18
인버스 ETF / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1748&amp;curPage=18
위험집중 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1749&amp;curPage=18
위탁증거금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1750&amp;curPage=18
운영 리스크(Operational Risk) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1751&amp;curPage=18
우선매수권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1752&amp;curPage=18
오픈뱅킹 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1753&amp;curPage=18
예금보험기금채권상환기금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1754&amp;curPage=18
역외재간접펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1755&amp;curPage=18
에스크로 방식 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1756&amp;curPage=17
업틱룰(uptick rule) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1757&amp;curPage=17
액면병합 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1758&amp;curPage=17
실제소유자 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1759&amp;curPage=17
실기주 과실 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1760&amp;curPage=17
신협 공동유대 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1761&amp;curPage=17
신자산건전성분류기준(Forward Looking Criteria) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1762&amp;curPage=17
신용평가 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1763&amp;curPage=17
신용거래 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1764&amp;curPage=17
신복위 채무조정 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1765&amp;curPage=17
시장조성자 제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1766&amp;curPage=16
스튜어드십 코드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1767&amp;curPage=16
손상차손 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1768&amp;curPage=16
소멸시효완성채권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1769&amp;curPage=16
선수금 환급보증(RG) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1770&amp;curPage=16
상각채권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1771&amp;curPage=16
사잇돌 대출 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1772&amp;curPage=16
사용가치 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1773&amp;curPage=16
사무관리회사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1774&amp;curPage=16
사기이용계좌 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1775&amp;curPage=16
비청산장외파생상품 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1776&amp;curPage=15
비조치의견서 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1777&amp;curPage=15
비소구 주택담보대출 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1778&amp;curPage=15
블라인드펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1779&amp;curPage=15
부실채권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1780&amp;curPage=15
21</pre></td>
</tr></table>

## 22쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p022.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">부동산개발신탁 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1781&amp;curPage=15
복합금융그룹 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1782&amp;curPage=15
복층ㆍ순환 투자구조 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1783&amp;curPage=15
보험다모아 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1784&amp;curPage=15
보험계리사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1785&amp;curPage=15
법령해석 및 비조치의견서 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1786&amp;curPage=14
방카슈랑스 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1787&amp;curPage=14
미수령주식ㆍ배당금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1788&amp;curPage=14
미수거래 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1789&amp;curPage=14
미니코스피200선물·옵션 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1790&amp;curPage=14
매입형 채무조정 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1791&amp;curPage=14
리파이낸싱 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1792&amp;curPage=14
리츠(REITs) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1793&amp;curPage=14
로보어드바이저 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1794&amp;curPage=14
레버리지 ETF / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1795&amp;curPage=14
등급쇼핑(rating shopping) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1796&amp;curPage=13
대환 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1797&amp;curPage=13
대표회사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1798&amp;curPage=13
대체투자 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1799&amp;curPage=13
단일가매매 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1800&amp;curPage=13
내부회계관리제도 감사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1801&amp;curPage=13
내부통제 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1802&amp;curPage=13
기업재무안정 PEF / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1803&amp;curPage=13
기업구조조정투자회사(CRV, Corporate Restructuring Vehicle) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1804&amp;curPage=1
3
기본예탁금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1805&amp;curPage=13
금융그룹 통합감독에 관한 원칙(Principles for the Supervision of Financial Conglomerates) / 용어 설명 /
https://www.fsc.go.kr/in090301/view?dicId=1806&amp;curPage=12
금융그룹 통합감독 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1807&amp;curPage=12
금융그룹 감독원칙 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1808&amp;curPage=12
금융그룹 감독대상 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1809&amp;curPage=12
금융규제 테스트베드(Regulatory sandbox) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1810&amp;curPage=12
금융규제 샌드박스 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1811&amp;curPage=12
금리인하요구권 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1812&amp;curPage=12
그룹위험 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1813&amp;curPage=12
국제기준 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1814&amp;curPage=12
괴리율 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1815&amp;curPage=12
공제 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1816&amp;curPage=11
공적자금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1817&amp;curPage=11
공모추가형 펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1818&amp;curPage=11
공동재보험 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1819&amp;curPage=11
공동대출 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1820&amp;curPage=11
고액현금거래보고 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1821&amp;curPage=11
고객확인제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1822&amp;curPage=11
22</pre></td>
</tr></table>

## 23쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p023.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">경영참여형 사모펀드(PEF, Private Equity Fund) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1823&amp;curPage=11
거래정보저장소 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1824&amp;curPage=11
감사인선임위원회 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1825&amp;curPage=11
감사인 지정 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1826&amp;curPage=10
TRS(Total Return Swap) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1827&amp;curPage=10
TDF(Target Date Fund) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1828&amp;curPage=10
TDB(Tech DataBase) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1829&amp;curPage=10
TCB(Tech Credit Bureau) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1830&amp;curPage=10
T+2일 결제제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1831&amp;curPage=10
SIFI(Systemically Important Financial Institution) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1832&amp;curPage=10
Self-Indexing / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1833&amp;curPage=10
Sale &amp; Leaseback / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1834&amp;curPage=10
PEF 업무집행사원 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1835&amp;curPage=10
PBS(Prime Brokerage Service) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1836&amp;curPage=9
MMF(Money Market Fund, 단기금융집합투자기구) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1837&amp;curPage=9
M&amp;A / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1838&amp;curPage=9
K-OTC / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1839&amp;curPage=9
IPO(기업공개, Initial Public Offering) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1840&amp;curPage=9
IMF FSAP(Financial Sector Assessment Program) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1841&amp;curPage=9
FSB(Financial Stability Board) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1842&amp;curPage=9
FATF 상호평가 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1843&amp;curPage=9
FATF / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1844&amp;curPage=9
ETN / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1845&amp;curPage=9
ETF(Exchange Traded Fund, 상장지수집합투자기구) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1846&amp;curPage=8
ELW / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1847&amp;curPage=8
DIP금융 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1848&amp;curPage=8
CB사(Credit Bureau, 개인신용조회회사) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1849&amp;curPage=8
Capital Call / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1850&amp;curPage=8
BIS 자기자본비율(BIS 비율) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1851&amp;curPage=8
ARS(Autonomous Restructuring Support) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1852&amp;curPage=8
금융체계상 중요한 금융기관(SIFI, Systemically Important Financial Institution) / 용어 설명 /
https://www.fsc.go.kr/in090301/view?dicId=1853&amp;curPage=8
정리제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1854&amp;curPage=8
FSB(Financial Stability Board) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1855&amp;curPage=8
채권자 손실분담제도(Bail-in) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1856&amp;curPage=7
적격금융거래(「채무자 회생 및 파산에 관한 법률」상 적격금융거래) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1857&amp;curP
age=7
개인대주제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1858&amp;curPage=7
공매도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1859&amp;curPage=7
신용공여 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1860&amp;curPage=7
전문투자자 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1861&amp;curPage=7
유상증자 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1862&amp;curPage=7
감독분담금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1863&amp;curPage=7
발행분담금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1864&amp;curPage=7
23</pre></td>
</tr></table>

## 24쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p024.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">공매도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1865&amp;curPage=7
백워데이션(back-wardation) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1866&amp;curPage=6
시장조성자(market maker) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1867&amp;curPage=6
업틱룰(up-tick rule) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1868&amp;curPage=6
금융체계상 중요한 금융기관(SIFI, Systemically Important Financial Institution) / 용어 설명 /
https://www.fsc.go.kr/in090301/view?dicId=1869&amp;curPage=6
정리제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1870&amp;curPage=6
적격금융거래(「채무자 회생 및 파산에 관한 법률」상 적격금융거래) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1871&amp;curP
age=6
기관전용 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1872&amp;curPage=6
일반 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1873&amp;curPage=6
일반투자자 대상 일반 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1874&amp;curPage=6
ROA(Return To Asset) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1875&amp;curPage=6
ROE(Return To Equity) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1876&amp;curPage=5
ABCP(AB전단채) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1877&amp;curPage=5
감사인 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1878&amp;curPage=5
지정감사 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1879&amp;curPage=5
주기적 지정제 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1880&amp;curPage=5
표준감사시간 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1881&amp;curPage=5
전기ㆍ당기 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1882&amp;curPage=5
기관전용 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1883&amp;curPage=5
일반 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1884&amp;curPage=5
일반투자자 대상 일반 사모펀드 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1885&amp;curPage=5
전환사채(Convertible Bonds) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1886&amp;curPage=4
국제회계기준(IFRS)재단 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1887&amp;curPage=4
IFRS 지속가능성 공시 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1888&amp;curPage=4
신속 이전상장제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1889&amp;curPage=4
지정자문인 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1890&amp;curPage=4
기본예탁금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1891&amp;curPage=4
소액투자 전용계좌 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1892&amp;curPage=4
기본예탁금 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1893&amp;curPage=4
소액투자 전용계좌 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1894&amp;curPage=4
신속 이전상장제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1895&amp;curPage=4
지정자문인 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1896&amp;curPage=3
상장사 감사인 등록제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1897&amp;curPage=3
감사인 지정제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1898&amp;curPage=3
감사인 지정점수 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1899&amp;curPage=3
감사인 지정제외점수 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1900&amp;curPage=3
SPAC(기업인수목적회사) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1901&amp;curPage=3
상향·하향 재지정 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1902&amp;curPage=3
동일군 재지정 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1903&amp;curPage=3
품질관리감리 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1904&amp;curPage=3
내부회계관리제도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1905&amp;curPage=3
국제회계기준(IFRS) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1906&amp;curPage=2
24</pre></td>
</tr></table>

## 25쪽

<table><tr>
<td width="50%" valign="top"><img src="images/financial_glossary_readable/p025.png" width="100%"></td>
<td width="50%" valign="top"><pre style="white-space: pre-wrap">국제감사기준(ISA) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1907&amp;curPage=2
P-CBO(Primary – Collateralized Bond Obligations, 신규발행채권담보부 증권) / 용어 설명 /
https://www.fsc.go.kr/in090301/view?dicId=1908&amp;curPage=2
PF(Project Financing) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1909&amp;curPage=2
Sales &amp; Lease Back(매각 후 재임대) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1910&amp;curPage=2
BDC(Business Development Company, 기업성장집합투자기구) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1911&amp;curPage=
2
D-테스트베드(D-Testbed) / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1912&amp;curPage=2
ESG / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1913&amp;curPage=2
ISSB / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1914&amp;curPage=2
IFRS S1,S2 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1915&amp;curPage=2
IOSCO / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1916&amp;curPage=1
ESRS / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1917&amp;curPage=1
SEC / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1918&amp;curPage=1
부수·겸영업무 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1919&amp;curPage=1
책무구조도 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1920&amp;curPage=1
IFRS재단 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1921&amp;curPage=1
IFRS 자문평의회 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1922&amp;curPage=1
IASB / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1923&amp;curPage=1
IFRS 해석위원회 / 용어 설명 / https://www.fsc.go.kr/in090301/view?dicId=1924&amp;curPage=1
25</pre></td>
</tr></table>
